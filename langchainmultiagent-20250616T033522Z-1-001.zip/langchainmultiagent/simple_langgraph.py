import operator
from typing import Annotated, TypedDict, Union

from colorama import Fore, Style

from langchain import hub
from langchain.agents import create_openai_functions_agent

from langchain_core.agents import AgentAction, AgentActionMessageLog, AgentFinish

from langchain_core.messages import BaseMessage
from langchain_core.runnables.base import Runnable

from langchain_openai.chat_models import ChatOpenAI
from langgraph.graph import END, StateGraph
from langgraph.prebuilt.tool_executor import ToolExecutor
from main import set_environment_variables

from tools import generate_image, get_weather, get_air_quality


set_environment_variables("LangGraph Basics")

LLM = ChatOpenAI(model="gpt-3.5-turbo-0125", streaming=True)

TOOLS = [get_weather, generate_image, get_air_quality]

PROMPT = hub.pull("hwchase17/openai-functions-agent")

class AgentState(TypedDict): #TypedDict lets us make a custom dictionary structure w/ all our agent keys
    input:str
    chat_history: list[BaseMessage] #base message is the thing  where its like ("system", "You are a hlfdlfdjlfd, your name is {name}".
    agent_outcome: Union[AgentAction, AgentFinish, None] #agentaction will be get_weatehr or generate _iamge
    intermediate_steps: Annotated[list[tuple[AgentAction, str]], operator.add] #same AgentAction, getweather, getiage, different\ce is that the action already happneed. the string is the output of that action
    #Annotated just lets us add stuff to th list

runnable_agent: Runnable = create_openai_functions_agent(LLM, TOOLS, PROMPT)


inputs = {
    "input": "give me the weather for new york please",
    "chat_history": [],
    "intermediate_steps": []
}

#agent_outcome = runnable_agent.invoke(inputs)

def agent_node(input: AgentState):
    agent_outcome: AgentActionMessageLog = runnable_agent.invoke(input)
    return {"agent_outcome": agent_outcome}


tool_executor = ToolExecutor(TOOLS)
#this will extract the arguments and the function the agent wants  to call
def tool_executor_node(input: AgentState):
    agent_action = input["agent_outcome"]
    output = tool_executor.invoke(agent_action)
    print(f"Executed {agent_action} with output: {output}")
    return {"intermediate_steps": [(agent_action, output)]}

def continue_or_end_test(data: AgentState):
    if isinstance(data["agent_outcome"], AgentFinish):
        return "END"
    else:
        return "continue"


#setting up langggraph

#create a stategraph langgraph
workflow = StateGraph(AgentState)

#add in our two nodes
workflow.add_node("agent", agent_node)
workflow.add_node("tool_executor", tool_executor_node)

#this is the first node
workflow.set_entry_point("agent")

#add edge (EDDDGGGINGGG)
#edges connect the nodes

workflow.add_edge("tool_executor", "agent") #always feed output into agent

workflow.add_conditional_edges(
    "agent", continue_or_end_test, {"continue": "tool_executor", "END": END}
)

#conditional edge format:

#workflow.add_conditional_edges(starting node, test function, return of function, link each node

#compile the graph

weather_app = workflow.compile()

def call_weather_app(query: str):
    inputs = {"input": query, "chat_history": []}
    output = weather_app.invoke(inputs)
    result = output.get("agent_outcome").return_values["output"]
    steps = output.get("intermediate_steps")

    print(f"{Fore.BLUE}Result: {result}{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}Steps: {steps}{Style.RESET_ALL}")

    return result


call_weather_app("Get the Air Quality in NewYork, then generate an image depciting the air quality")