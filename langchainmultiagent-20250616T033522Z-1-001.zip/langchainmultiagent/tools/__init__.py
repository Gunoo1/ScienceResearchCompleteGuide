from .image import generate_image
from .weather import get_weather
from .air_quality import get_air_quality
from .pdf import markdown_to_pdf_file
from .web import get_webpage_content