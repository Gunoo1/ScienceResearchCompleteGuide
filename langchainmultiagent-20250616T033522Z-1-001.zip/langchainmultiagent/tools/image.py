import uuid #creates unique file names
from pathlib import Path #for defining save image path

import requests #send request to generate image

from decouple import config #read .env file
from langchain.tools import tool #for definign our tool
from openai import OpenAI  #for requesting from DALLI
from pydantic import BaseModel, Field #DEFINE THE INPUT OF OUR TOOL

IMAGE_DIRECTORY = Path(__file__).parent.parent / "images"

CLIENT = OpenAI(api_key=str(config("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", default="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")))

def image_downloader(image_url: str | None) -> str:
    if image_url is None:
        return "No images returned from API"
    response = requests.get(image_url)
    if response.status_code != 200:
        return "could not get image from URL"
    unique_id : uuid.UUID = uuid.uuid4() #make new uuid instance (this is what uuid4 does
    image_path = IMAGE_DIRECTORY / f"{unique_id}.png"
    with open(image_path, "wb") as file:
        file.write(response.content)
    return str(image_path)

class GenerateImageInput(BaseModel): #inherit from pydantic basemodel
    image_description: str = Field(
        description="A detailed description of the desired image."
    )

@tool("generate_image", args_schema=GenerateImageInput)
def generate_image(image_description: str) -> str:
    """Generate image based on a detailed description.""" #this HAS to be GOOD because this description is what the LLM agent uses to understand what the tool does

    response = CLIENT.images.generate(
        model="dall-e-3",
        prompt=image_description,
        size="1024x1024",
        quality="standard",
        n=1
    )
    image_url = response.data[0].url
    return image_downloader(image_url)
