from json import dumps

import requests

from decouple import config
from langchain.tools import tool
from pydantic import BaseModel, Field


class WeatherInput(BaseModel):
    location: str = Field(
        description="Must be a valid location in city format."
    )

@tool("get_weather", args_schema=WeatherInput)
def get_weather(location: str) -> str:
    """Get the current weather for a specified location"""
    if not location:
        return(
            "Please provide a location and call the get_current_weather_function again."
            )
    API_params = {
        "key": str(config("a792bf9847b54101b7940338241005", default="a792bf9847b54101b7940338241005")),
        "q": location,
        "aqi": "no",
        "alerts": "no"
    }
    response: requests.models.Response = requests.get(
        "http://api.weatherapi.com/v1/current.json", params=API_params
    )
    str_reponse: str = dumps(response.json())
    return str_reponse

if __name__ == "__main__":
    print(get_weather.run("New York"))