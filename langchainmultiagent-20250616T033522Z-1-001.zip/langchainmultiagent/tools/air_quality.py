from json import dumps


import requests

from decouple import config

from langchain.tools import tool
from pydantic import BaseModel, Field

class AirQInput(BaseModel):
    location: str = Field(
        description="Must be a valid location in city format"
    )

@tool("get_air_quality", args_schema=AirQInput)
def get_air_quality(location: str) -> str:
    """Get the current air quality for a specified location"""
    if not location:
        return(
            "Please provide a location and call the get_air_quality function again"
        )
    API_params = {
        "x-api-key": "392209ff844d9ac8f9c30bd07e65054edbe0a32f6f140739bf39045079ae81f9",
        "Content-type": "application/json"

    }

    # Define the API endpoint and parameters
    url = "https://api.ambeedata.com/latest/by-city"
    params = {"city": location}
    headers = API_params

    # Make the GET request using the requests library
    response: requests.models.Response = requests.get(url, params=params, headers=headers)

    # Convert the response to a JSON string
    str_response: str = dumps(response.json())

    # Return the JSON string
    return str_response


if __name__ == "__main__":
    print(get_air_quality.run("NewYork"))