from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

from main import set_environment_variables
set_environment_variables()

translate_to_french = ChatPromptTemplate.from_template("Translate the following text to russian: {text}")
output_parser = StrOutputParser()
llm = ChatOpenAI(model="gpt-3.5-turbo-0125")

chain = translate_to_french | llm | output_parser


print(chain.invoke({"text": "and i oop"}))



