import functools

def multiply(x, y):
    return x*y

multiplyby2 = functools.partial(multiply, x=2)

result = multiplyby2(3)
print(result)