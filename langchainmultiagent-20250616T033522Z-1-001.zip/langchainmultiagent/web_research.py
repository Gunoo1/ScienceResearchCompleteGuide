import functools
import operator
from typing import Annotated, Sequence, TypedDict
import os
from decouple import config

from langchain_openai import ChatOpenAI
from web_research_prompts import (
TAVILY_AGENT_SYSTEM_PROMPT,
RESEARCHER_SYSTEM_PROMPT
)
from colorama import Fore, Style
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain.output_parsers.openai_functions import JsonOutputFunctionsParser
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.messages import BaseMessage, HumanMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.language_models.chat_models import BaseChatModel
from langgraph.graph import END, StateGraph
from tools.pdf import OUTPUT_DIRECTORY
from tools.web import research
from main import set_environment_variables
import asyncio
import operator
import uuid
set_environment_variables("Web_Search_graph")

LLM = ChatOpenAI(model="gpt-3.5-turbo-0125")
TAVILY_TOOL = TavilySearchResults(max_results=6)

TAVILY_AGENT_NAME = "tavily_agent"
RESEARCHER_AGENT_NAME = "search_evaluator_agent"

SAVE_FILE_NODE_NAME = "save_file"

def create_agent(llm: BaseChatModel, tools: list, system_prompt: str):
    prompt_template = ChatPromptTemplate.from_messages(
        [
            ("system", system_prompt),
            MessagesPlaceholder(variable_name="messages"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ]

    )
    agent = create_openai_tools_agent(llm, tools, prompt_template)
    agent_executor = AgentExecutor(agent=agent, tools=tools)
    return agent_executor

class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], operator.add]


def agent_node(state: AgentState, agent, name):
    print('hi')
    print(state)
    result = agent.invoke(state)
    return {"messages": [HumanMessage(content=result["output"], name=name)]}


async def async_agent_node(state: AgentState, agent, name):
    result = await agent.ainvoke(state) #wait for this to finish
    return {"messages": [HumanMessage(content=result["output"], name=name)]}



tavily_agent = create_agent(llm=LLM, tools=[TAVILY_TOOL], system_prompt=TAVILY_AGENT_SYSTEM_PROMPT)

tavily_agent_node = functools.partial(
    agent_node, agent=tavily_agent, name=TAVILY_AGENT_NAME
)

research_agent = create_agent(llm=LLM, tools=[research], system_prompt=RESEARCHER_SYSTEM_PROMPT)

research_agent_node = functools.partial(
    async_agent_node, agent=research_agent, name=RESEARCHER_AGENT_NAME
)

def save_file_node(state: AgentState):
    markdown_content = str(state["messages"][-1].content) #-1 is where the research is
    filename = f"{OUTPUT_DIRECTORY}/{uuid.uuid4()}.md"
    with open(filename, "w", encoding="utf-8") as file:
        file.write(markdown_content)
    return{
        "messages" : [
            HumanMessage(
                content = f"Output written successfully to {filename}",
                name=SAVE_FILE_NODE_NAME #tell the agent the file was written successfuly?
            )
        ]
    }

workflow = StateGraph(AgentState)

workflow.add_node(TAVILY_AGENT_NAME, tavily_agent_node)

workflow.add_node(RESEARCHER_AGENT_NAME, research_agent_node)
workflow.add_node(SAVE_FILE_NODE_NAME, save_file_node)

workflow.add_edge(TAVILY_AGENT_NAME, RESEARCHER_AGENT_NAME)
workflow.add_edge(RESEARCHER_AGENT_NAME, SAVE_FILE_NODE_NAME)

workflow.add_edge(SAVE_FILE_NODE_NAME, END)
workflow.set_entry_point(TAVILY_AGENT_NAME)

research_graph = workflow.compile()

async def run_research_graph(input):
    async for output in research_graph.astream(input):
        for node_name, output_value in output.items():
            print("_____")
            print(f"Output from node '{node_name}':")
            print(output_value)
        print("\n---\n")


test_input = {"messages": [HumanMessage(content="Jaws")]}

asyncio.run(run_research_graph(test_input))